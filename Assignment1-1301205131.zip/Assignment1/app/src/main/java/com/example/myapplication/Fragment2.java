package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment2Binding;

public class Fragment2 extends Fragment {

    public static Fragment2Binding fragment2Binding;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    // Interface for sending data back to the Host Activity
    public interface OnFragment2DataListener {
        void onFragment2Continue(String name, String email, String gender);
    }

    private OnFragment2DataListener listener;

    public Fragment2() {
        // Required empty public constructor
    }

    public static Fragment2 newInstance(String param1, String param2) {
        Fragment2 fragment = new Fragment2();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragment2DataListener) {
            listener = (OnFragment2DataListener) context;
        } else {
            throw new RuntimeException(context + " must implement OnFragment2DataListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragment2Binding = Fragment2Binding.inflate(inflater, container, false);

        fragment2Binding.buttonContinue.setOnClickListener(view -> {
            String name   = fragment2Binding.editTextName.getText().toString().trim();
            String email  = fragment2Binding.editTextEmail.getText().toString().trim();
            String gender = fragment2Binding.radioMale.isChecked()   ? "Male"
                          : fragment2Binding.radioFemale.isChecked() ? "Female"
                          : "Prefer not to say";

            if (name.isEmpty()) {
                fragment2Binding.editTextName.setError("Please enter your name");
                return;
            }
            if (email.isEmpty()) {
                fragment2Binding.editTextEmail.setError("Please enter your email");
                return;
            }

            if (listener != null) {
                listener.onFragment2Continue(name, email, gender);
            }
        });

        return fragment2Binding.getRoot();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity
        implements Fragment2.OnFragment2DataListener,
                   Fragment3.OnFragment3CheckboxListener {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Hide the old activity-level button – each fragment manages its own Continue
        binding.buttonContinue.setVisibility(android.view.View.GONE);

        // Start with Fragment1
        Fragment1 fragment1 = Fragment1.newInstance(null, null);
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container, fragment1)
                .commit();
    }

    // Called by Fragment1's Continue button (handled in Fragment1 itself via the Activity)
    public void navigateToFragment2() {
        Fragment2 fragment2 = Fragment2.newInstance(null, null);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment2)
                .addToBackStack(null)
                .commit();
    }

    // ── Fragment2.OnFragment2DataListener ────────────────────────────────────
    @Override
    public void onFragment2Continue(String name, String email, String gender) {
        Toast.makeText(this,
                "Hello " + name + " | " + email + " | " + gender,
                Toast.LENGTH_SHORT).show();

        // Pass the name to Fragment3 via Bundle / setArguments
        Fragment3 fragment3 = Fragment3.newInstance(name);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment3)
                .addToBackStack(null)
                .commit();
    }

    // ── Fragment3.OnFragment3CheckboxListener ────────────────────────────────
    @Override
    public void onCheckboxChanged(boolean isChecked) {
        // Host Activity is notified of checkbox state if needed for future use
    }
}

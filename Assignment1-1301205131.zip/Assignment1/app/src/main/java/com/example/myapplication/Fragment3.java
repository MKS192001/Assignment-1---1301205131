package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment3Binding;

public class Fragment3 extends Fragment {

    private static final String ARG_NAME = "user_name";

    private String userName;
    private Fragment3Binding binding;

    // Interface for checkbox state changes
    public interface OnFragment3CheckboxListener {
        void onCheckboxChanged(boolean isChecked);
    }

    private OnFragment3CheckboxListener listener;

    public Fragment3() {
        // Required empty public constructor
    }

    public static Fragment3 newInstance(String name) {
        Fragment3 fragment = new Fragment3();
        Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragment3CheckboxListener) {
            listener = (OnFragment3CheckboxListener) context;
        } else {
            throw new RuntimeException(context + " must implement OnFragment3CheckboxListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            userName = getArguments().getString(ARG_NAME);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = Fragment3Binding.inflate(inflater, container, false);

        // Display user's name
        binding.textViewWelcome.setText("Welcome, " + userName + "!");

        // Button starts disabled
        binding.buttonFinish.setEnabled(false);

        // Checkbox listener – drives button state and text
        binding.checkboxConfirm.setOnCheckedChangeListener((buttonView, isChecked) -> {
            binding.buttonFinish.setEnabled(isChecked);
            binding.buttonFinish.setText(isChecked ? "Finish" : "Continue");

            if (listener != null) {
                listener.onCheckboxChanged(isChecked);
            }
        });

        return binding.getRoot();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
